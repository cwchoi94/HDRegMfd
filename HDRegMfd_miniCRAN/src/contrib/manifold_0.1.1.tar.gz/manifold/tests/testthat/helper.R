MakeSOMat <- function(v, method='Higham08.b') {

  ExpM(MakeSkewSym(v))

}
